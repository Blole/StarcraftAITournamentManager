Chaoslauncher by MasterofChaos
Version 0.5.3 for Starcraft 1.16.1

Replacement for BWLauncher 4
To load Bwlauncherplugins not included in this package simply put them in the launcher directory.

Notes:
W-Mode works with all SC-Versions
To use AdvLoader plugins simply install AdvLoader

Betaversion - May still contain bugs
Like every 3rd partytool working together with Starcraft there is a small risk, that Blizzard decides to invalidate the users Accounts/CD-Keys.
USE AT YOUR OWN RISK!